package org.mymp3;

import java.io.Serializable;

public class Track implements Serializable {
	private long id;
	
	private String path;

	private String title;

	private String folder;
	
	private String album;

	private String artist;

	private long bookmark;

	private String composer;

	private long duration;
	

	public Track() {
	}

	public Track(long id, String path, String title, String folder/*, String album, String artist, long bookmark, String composer, long duration*/) {
		this.id = id;
		this.path = path;
		this.title = title;
		this.folder = folder;
/*		
		this.album = album;
		this.artist = artist;
		this.bookmark = bookmark;
		this.composer = composer;
		this.duration = duration;
*/		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFolder() {
		return folder;
	}

	public void setFolder(String folder) {
		this.folder = folder;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public long getBookmark() {
		return bookmark;
	}

	public void setBookmark(long bookmark) {
		this.bookmark = bookmark;
	}

	public String getComposer() {
		return composer;
	}

	public void setComposer(String composer) {
		this.composer = composer;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}
}
