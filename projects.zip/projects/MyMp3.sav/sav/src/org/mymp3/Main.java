package org.mymp3;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.app.ListActivity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.widget.ListView;

public final class Main extends ListActivity { 
	protected static final int MENU_EDIT = 1;

	protected static final int MENU_CLOSE = 2;
	
	private ArrayList<Track> list;
	
	private ListAdapter listAdapter;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	try {
            super.onCreate(savedInstanceState);
            
            setContentView(R.layout.main);

            list = new ArrayList<Track>();
            
            getList();
            
            Collections.sort(list, new Comparator<Track>(){
           	  public int compare(Track a, Track b){
           	    return a.getPath().compareTo(b.getPath());
           	  }
           	});
            
            listAdapter = new ListAdapter(this, list);
            setListAdapter(listAdapter);
            
            getListView().setOnCreateContextMenuListener(new OnCreateContextMenuListener() {
    			public void onCreateContextMenu(ContextMenu menu, View view, ContextMenuInfo menuInfo) {
    				menu.add(0, MENU_EDIT, Menu.NONE, "Edit");
    				menu.add(0, MENU_CLOSE, Menu.NONE, "Close");
//    				menu.add(0, CONTEXTMENU_MARKASREAD_ID, Menu.NONE, R.string.contextmenu_markasread);
    			}
            });
		} catch (Throwable e) {
			Utils.showDialog(this, e);
		}
    }
    public void getList() {
    	//retrieve track info
    	ContentResolver musicResolver = getContentResolver();
    	
    	Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    	Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);
    	
    	if(musicCursor!=null && musicCursor.moveToFirst()) {
    		  //get columns
    		  int idColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media._ID);
    		  int dataColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.DATA);
/*    		  
    		  int albumColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.ALBUM);
    		  int artistColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.ARTIST);
    		  int bookmarkColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.BOOKMARK);
    		  int composerColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.COMPOSER);
    		  int durationColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.DURATION);
*/    		  
    		  //add songs to list
    		  do {
    		    String path = musicCursor.getString(dataColumn);
				if(path.toLowerCase().endsWith(".mp3") && path.contains("/MP3/")) {
	    		    long id = musicCursor.getLong(idColumn);
	    			String title = path.substring(path.lastIndexOf("/")+1, path.lastIndexOf("."));
	    			String folder = path.substring(0, path.lastIndexOf("/"));
	    			folder = folder.substring(folder.lastIndexOf("/")+1);				

/*	    			
	    			String album = musicCursor.getString(albumColumn);
	    			String artist = musicCursor.getString(artistColumn);
	    			long bookmark = musicCursor.getLong(bookmarkColumn);
	    			String composer = musicCursor.getString(composerColumn);
	    			long duration = musicCursor.getLong(durationColumn);
*/	    			
	    		    list.add(new Track(id, path, title, folder/*, album, artist, bookmark, composer, duration*/));
				}
    		    
    		  }
    		  while (musicCursor.moveToNext());
   		}
    	
   	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {		
			case R.id.actionEnd: 
			case MENU_CLOSE: 
		    	System.exit(0);
				break;
			case MENU_EDIT:
				break;
		}
		return true;
	}
   @Override
   protected void onDestroy() {
      super.onDestroy();
   }
   @Override
   protected void onListItemClick(ListView listView, View view, int position, long id) {
	   Utils.call(this, list, Integer.parseInt(view.getTag().toString()));
//      Intent intent = new Intent(this, Detail.class);
//      Track track = list.get(Integer.parseInt(view.getTag().toString()));
//      intent.putExtra("index", );
//      intent.putExtra("list", list);
//      startActivity(intent);
   }
}
