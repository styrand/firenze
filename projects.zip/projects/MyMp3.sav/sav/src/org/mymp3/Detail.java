package org.mymp3;

import java.util.ArrayList;

import android.app.Activity;
import android.content.ContentUris;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.DateUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.MediaController.MediaPlayerControl;
import android.widget.TextView;

public class Detail extends Activity implements MediaPlayerControl {
//    private static final int SEEK_TO_REWIND = -30000;
//
//    private static final int SEEK_TO_FORWARD = 120000;

	
    private MediaController mediaController;
    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler();
    
    private ArrayList<Track> list;
    private int index;
    private Track detail;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.detail);
            
            list = (ArrayList<Track>)getIntent().getSerializableExtra("list");
            index = getIntent().getIntExtra("index", 0);
            detail = list.get(index);
            
            setTextView(R.id.title, "Title : "+detail.getTitle());
            setTextView(R.id.folder, "Folder : "+detail.getFolder());
/*            
            setTextView(R.id.album, "Album : "+detail.getAlbum());
            setTextView(R.id.artist, "Artist : "+detail.getArtist());
            setTextView(R.id.composer, "Composer : "+detail.getComposer());
            setTextView(R.id.bookmark, "Bookmark : "+ DateUtils.formatElapsedTime(detail.getBookmark() / 1000)+"/"+DateUtils.formatElapsedTime(detail.getDuration() / 1000));
*/            
            Button btnPrev = (Button)findViewById(R.id.btnPrev);
            Button btnNext = (Button)findViewById(R.id.btnNext);
    		
            btnPrev.setOnClickListener(new OnClickListener() {
    			public void onClick(View view) {
    				playPrev();
    			}
    		});    
            btnNext.setOnClickListener(new OnClickListener() {
    			public void onClick(View view) {
    				playNext();
    			}
    		});    
            
    	  	
    	  	//set media player
    	  	//get id
    	  	long trackId = detail.getId();
    	  	//set uri
    	  	Uri trackUri = ContentUris.withAppendedId(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, trackId);
            

            mediaPlayer = new MediaPlayer();
            mediaController = new MediaController(this);
            mediaController.setMediaPlayer(Detail.this);
            mediaController.setAnchorView(findViewById(R.id.audioView));
           	mediaPlayer.setDataSource(getApplicationContext(), trackUri);
            mediaPlayer.prepare();
            
            if(detail.getBookmark() != 0) {
            	mediaPlayer.seekTo((int)detail.getBookmark());
            }
            
            mediaPlayer.setOnPreparedListener(new OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                        handler.post(new Runnable() {
                                public void run() {
                                        mediaController.show(0);
                                        mediaPlayer.start();
                                }
                        });
                }
            });
            
            mediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mediaController.hide();
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    
                    index = index +1;
                    if(index >= list.size()) {
                       index = 0;                    	 
                    }
                    Utils.call(Detail.this, list, index);
                }
            });
			
		} catch (Throwable e) {
			Utils.showDialog(this, e);
		}
    }
    
    protected void playNext() {
        index = index +1;
        if(index >= list.size()) {
            index = 0;                    	 
        }
        Utils.call(Detail.this, list, index);
    }
    protected void playPrev() {
        index = index - 1;
        if(index < 0) {
            index = list.size() - 1;                    	 
        }
        Utils.call(Detail.this, list, index);
    }
    
    protected void setTextView(int id, String text) {
        TextView textView = (TextView)findViewById(id);
        textView.setText(text);    	
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaController.hide();
        mediaPlayer.stop();
        mediaPlayer.release();
    }
    
    @Override
    public boolean canPause() {
        return true;
    }

    @Override
    public boolean canSeekBackward() {
        return true;
    }

    @Override
    public boolean canSeekForward() {
        return true;
    }

    @Override    
    public int getBufferPercentage() {
        int percentage = (mediaPlayer.getCurrentPosition() * 100) / mediaPlayer.getDuration();
        return percentage;
    }

    @Override
    public int getCurrentPosition() {
        return mediaPlayer.getCurrentPosition();
    }

    @Override
    public int getDuration() {
        return mediaPlayer.getDuration();
    }

    @Override
    public boolean isPlaying() {
        return mediaPlayer.isPlaying();
    }

    @Override
    public void pause() {
        if(mediaPlayer.isPlaying())
            mediaPlayer.pause();
    }

    @Override
    public void seekTo(int pos) {
        mediaPlayer.seekTo(pos);
    }

    @Override
    public void start() {
        mediaPlayer.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mediaController.show();
        
        return false;
    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.detail, menu);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {		
			case R.id.actionEnd: 
		    	System.exit(0);
			break;
		}
		return true;
	}
    
}
