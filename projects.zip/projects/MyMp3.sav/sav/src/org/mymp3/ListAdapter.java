package org.mymp3;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;


public class ListAdapter extends BaseAdapter {
	private ArrayList<Track> list;
	private LayoutInflater layoutInf;

	public ListAdapter(Context c, ArrayList<Track> list){
		this.list = list;
		layoutInf = LayoutInflater.from(c);
	}
	
	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int arg0) {
		return null;
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
	  //map to song layout
	  LinearLayout trackLayout = (LinearLayout)layoutInf.inflate(R.layout.item, parent, false);
	  
	  //get title and artist views
	  TextView titleView = (TextView)trackLayout.findViewById(R.id.title);
	  TextView folderView = (TextView)trackLayout.findViewById(R.id.folder);
	  
	  //get track using position
	  Track track = list.get(position);
	  
	  //get title and artist strings
	  titleView.setText(track.getTitle());
	  titleView.setTypeface(Typeface.DEFAULT_BOLD);
	  
	  folderView.setText(track.getFolder());
	  folderView.setTypeface(Typeface.DEFAULT);
	  
	  //set position as tag
	  trackLayout.setTag(position);
	  return trackLayout;
	}


}
