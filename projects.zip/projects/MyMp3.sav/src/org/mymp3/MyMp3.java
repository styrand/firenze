package org.mymp3;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.app.ListActivity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.widget.ListView;

public final class MyMp3 extends ListActivity { 
	protected static final int MENU_EDIT = 1;

	protected static final int MENU_CLOSE = 2;
	
	private ArrayList<Track> trackList;
	
	private TrackAdapter trackAdapter;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	try {
            super.onCreate(savedInstanceState);
            
            setContentView(R.layout.main);

            trackList = new ArrayList<Track>();
            
            getTrackList();
            
            Collections.sort(trackList, new Comparator<Track>(){
           	  public int compare(Track a, Track b){
           	    return a.getPath().compareTo(b.getPath());
           	  }
           	});
            
            trackAdapter = new TrackAdapter(this, trackList);
            setListAdapter(trackAdapter);
            
            getListView().setOnCreateContextMenuListener(new OnCreateContextMenuListener() {
    			public void onCreateContextMenu(ContextMenu menu, View view, ContextMenuInfo menuInfo) {
    				menu.add(0, MENU_EDIT, Menu.NONE, "Edit");
    				menu.add(0, MENU_CLOSE, Menu.NONE, "Close");
//    				menu.add(0, CONTEXTMENU_MARKASREAD_ID, Menu.NONE, R.string.contextmenu_markasread);
    			}
            });
		} catch (Throwable e) {
			Utils.showDialog(this, e);
		}
    }
    public void getTrackList() {
    	//retrieve track info
    	ContentResolver musicResolver = getContentResolver();
    	
    	Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    	Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);
    	
    	if(musicCursor!=null && musicCursor.moveToFirst()) {
    		  //get columns
    		  int dataColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.DATA);
    		  int idColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media._ID);
    		  int bookmarkColumn = musicCursor.getColumnIndex(android.provider.MediaStore.Audio.Media.BOOKMARK);
    		  
    		  //add songs to list
    		  do {
    		    String path = musicCursor.getString(dataColumn);
				if(path.toLowerCase().endsWith(".mp3") && path.contains("/MP3/")) {
	    		    long id = musicCursor.getLong(idColumn);
	    			String title = path.substring(path.lastIndexOf("/")+1, path.lastIndexOf("."));
	    			String folder = path.substring(0, path.lastIndexOf("/"));
	    			folder = folder.substring(folder.lastIndexOf("/")+1);		
	    			long bookmark = musicCursor.getLong(bookmarkColumn);
            		
	    		    trackList.add(new Track(id, path, title, folder, bookmark));
				}
    		    
    		  }
    		  while (musicCursor.moveToNext());
   		}
    	
   	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {		
			case R.id.actionEnd: 
			case MENU_CLOSE: 
		    	System.exit(0);
				break;
			case MENU_EDIT:
				break;
		}
		return true;
	}
   @Override
   protected void onDestroy() {
      super.onDestroy();
   }
   @Override
   protected void onListItemClick(ListView listView, View view, int position, long id) {
      Intent intent = new Intent(this, TrackActivity.class);
      int index = Integer.parseInt(view.getTag().toString());
      Track track = trackList.get(index);
      intent.putExtra("index", index);
      intent.putExtra("track", track);
      intent.putExtra("trackList", trackList);
      startActivity(intent);
   }
}
