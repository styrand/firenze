package org.mymp3;

import java.io.Serializable;

public class Track implements Serializable {
	private long id;
	
	private String path;

	private String title;

	private String folder;
	
	private long bookmark;

	public Track() {
	}
	
	public Track(long id, String path, String title, String folder, long bookmark) {
		this.id = id;
		this.path = path;
		this.title = title;
		this.folder = folder;
		this.bookmark = bookmark;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFolder() {
		return folder;
	}

	public void setFolder(String folder) {
		this.folder = folder;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	public long getBookmark() {
		return bookmark;
	}

	public void setBookmark(long bookmark) {
		this.bookmark = bookmark;
	}
	
}
