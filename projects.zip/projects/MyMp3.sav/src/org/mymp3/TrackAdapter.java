package org.mymp3;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;


public class TrackAdapter extends BaseAdapter {
	private ArrayList<Track> trackList;
	private LayoutInflater trackInf;

	public TrackAdapter(Context c, ArrayList<Track> trackList){
		this.trackList = trackList;
		trackInf = LayoutInflater.from(c);
	}
	
	@Override
	public int getCount() {
		return trackList.size();
	}

	@Override
	public Object getItem(int arg0) {
		return null;
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
	  //map to song layout
	  LinearLayout trackLayout = (LinearLayout)trackInf.inflate(R.layout.track, parent, false);
	  //get title and artist views
	  TextView titleView = (TextView)trackLayout.findViewById(R.id.trackTitle);
	  TextView folderView = (TextView)trackLayout.findViewById(R.id.trackFolder);
	  //get track using position
	  Track track = trackList.get(position);
	  //get title and artist strings
	  titleView.setText(track.getTitle());
	  titleView.setTypeface(Typeface.DEFAULT_BOLD);
	  
	  folderView.setText(track.getFolder());
	  folderView.setTypeface(Typeface.DEFAULT);
	  
	  //set position as tag
	  trackLayout.setTag(position);
	  return trackLayout;
	}


}
