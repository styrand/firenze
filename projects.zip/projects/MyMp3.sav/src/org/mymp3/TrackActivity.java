package org.mymp3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.app.Activity;
import android.content.ContentUris;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.MediaController;
import android.widget.MediaController.MediaPlayerControl;
import android.widget.TextView;
import android.view.View;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View.OnClickListener;
import android.widget.Button;

public class TrackActivity extends Activity implements MediaPlayerControl {
//    private static final int SEEK_TO_REWIND = -30000;
//
//    private static final int SEEK_TO_FORWARD = 120000;

	
    private MediaController mMediaController;
    private MediaPlayer mMediaPlayer;
    private Handler mHandler = new Handler();
    
    private Track track;
    private int index;
    private ArrayList<Track> trackList;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.track_activity);
            
            track = (Track)getIntent().getSerializableExtra("track");
            int index = getIntent().getIntExtra("index", 0);
            trackList = (ArrayList<Track>)getIntent().getSerializableExtra("trackList");
            
    	  	//set title
            TextView trackTitle = (TextView)findViewById(R.id.trackTitle);
    	  	trackTitle.setText(track.getTitle());
    	  	
    	  	//set folder
            TextView trackFolder = (TextView)findViewById(R.id.trackFolder);
            trackFolder.setText(track.getFolder());
            
            Button btnPrev = (Button)findViewById(R.id.btnPrev);
            Button btnNext = (Button)findViewById(R.id.btnNext);
    		
            btnPrev.setOnClickListener(new OnClickListener() {
    			public void onClick(View view) {
    				playPrev();
    			}
    		});    
            btnNext.setOnClickListener(new OnClickListener() {
    			public void onClick(View view) {
    				playNext();
    			}
    		});    
            
    	  	    	      	  	
    	  	//set media player
    	  	//get id
    	  	long trackId = track.getId();
    	  	//set uri
    	  	Uri trackUri = ContentUris.withAppendedId(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, trackId);
            

            mMediaPlayer = new MediaPlayer();
            mMediaController = new MediaController(this);
            mMediaController.setMediaPlayer(TrackActivity.this);
            mMediaController.setAnchorView(findViewById(R.id.audioView));
           	mMediaPlayer.setDataSource(getApplicationContext(), trackUri);
            mMediaPlayer.prepare();
            
            if(track.getBookmark() != 0) {
            	mMediaPlayer.seekTo((int)track.getBookmark());
            }            
            /*
            mMediaPlayer.setOnPreparedListener(new OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                        mHandler.post(new Runnable() {
                                public void run() {
                                        mMediaController.show(10000);
                                        mMediaPlayer.start();
                                }
                        });
                }
            });
            */
            mMediaPlayer.setOnPreparedListener(new OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                        mHandler.post(new Runnable() {
                                public void run() {
                                        mMediaController.show(0);
                                        mMediaPlayer.start();
                                }
                        });
                }
            });
            
            mMediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mMediaController.hide();
                    mMediaPlayer.stop();
                    mMediaPlayer.release();
                }
            });
            
			
		} catch (Throwable e) {
			Utils.showDialog(this, e);
		}
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mMediaController.hide();
        mMediaPlayer.stop();
        mMediaPlayer.release();
    }
    
    @Override
    public boolean canPause() {
        return true;
    }

    @Override
    public boolean canSeekBackward() {
        return true;
    }

    @Override
    public boolean canSeekForward() {
        return true;
    }

    @Override    
    public int getBufferPercentage() {
        int percentage = (mMediaPlayer.getCurrentPosition() * 100) / mMediaPlayer.getDuration();
        return percentage;
    }

    @Override
    public int getCurrentPosition() {
        return mMediaPlayer.getCurrentPosition();
    }

    @Override
    public int getDuration() {
        return mMediaPlayer.getDuration();
    }

    @Override
    public boolean isPlaying() {
        return mMediaPlayer.isPlaying();
    }

    @Override
    public void pause() {
        if(mMediaPlayer.isPlaying())
            mMediaPlayer.pause();
    }

    @Override
    public void seekTo(int pos) {
        mMediaPlayer.seekTo(pos);
    }

    @Override
    public void start() {
        mMediaPlayer.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mMediaController.show();
        
        return false;
    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.track_activity, menu);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {		
			case R.id.actionEnd: 
		    	System.exit(0);
			break;
		}
		return true;
	}
    protected void playNext() {
        index = index +1;
        if(index >= trackList.size()) {
            index = 0;                    	 
        }
      Intent intent = new Intent(this, TrackActivity.class);
      Track track = trackList.get(index);
      intent.putExtra("index", index);
      intent.putExtra("track", track);
      intent.putExtra("trackList", trackList);
      startActivity(intent);
    }
    protected void playPrev() {
        index = index - 1;
        if(index < 0) {
            index = trackList.size() - 1;                    	 
        }
      Intent intent = new Intent(this, TrackActivity.class);
      Track track = trackList.get(index);
      intent.putExtra("index", index);
      intent.putExtra("track", track);
      intent.putExtra("trackList", trackList);
      startActivity(intent);
    }
	
    
}
