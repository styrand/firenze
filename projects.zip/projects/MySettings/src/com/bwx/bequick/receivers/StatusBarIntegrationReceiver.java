/*
 * Copyright (C) 2010 beworx.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.bwx.bequick.receivers;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import android.app.Activity;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.provider.Settings;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.bwx.bequick.Constants;
import com.bwx.bequick.R;
import com.bwx.bequick.ShowSettingsActivity;

public class StatusBarIntegrationReceiver extends BroadcastReceiver {
	private static final String ACTION_ROTATE = "com.bwx.bequick.ROTATE";

	private static final String ACTION_BRIGHTNESS = "com.bwx.bequick.BRIGHTNESS";
	
	private static final String ACTION_AIRPLANE = "com.bwx.bequick.AIRPLANE";

	private static final String ACTION_SILENT = "com.bwx.bequick.SILENT";
	
	private static final String ACTION_MEDIAVOLUME = "com.bwx.bequick.MEDIAVOLUME";

	private static final String ACTION_DATA1 = "com.bwx.bequick.DATA1";

	private static final String ACTION_DATA2 = "com.bwx.bequick.DATA2";
	
	//private static final String TAG = "StatusBarIntegrationReceiver";
	private static final int SHORTCUT_NOTIFICATION = 0;
	
	private static final int MINIMUM_BACKLIGHT = 18;
	
	private static final int RANGE_BACKLIGHT = 60;	
	
	private static final int MAXIMUM_BACKLIGHT = 255;
	
	
	// cache
	private Notification mNotification;
	
	private AudioManager audioManager;
	
	@Override
	public void onReceive(final Context context, Intent intent) {

		String action = intent.getAction();
		if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
			
			// read configuration
			SharedPreferences prefs = context.getSharedPreferences(Constants.PREFS_COMMON, 0);
			
			int status = Integer.parseInt(prefs.getString(Constants.PREF_STATUSBAR_INTEGRATION, "-1"));
			if (status > 0) {
				// show notification if it was configured to be shown
				int appearence = Integer.parseInt(prefs.getString(Constants.PREF_APPEARANCE, "0"));
				boolean invert = prefs.getBoolean(Constants.PREF_INVERSE_VIEW_COLOR, false);
				sendNotification(context, status, appearence, invert);
			}

		} else if (Constants.ACTION_UPDATE_STATUSBAR_INTEGRATION.equals(action)) {

			int status = intent.getIntExtra(Constants.EXTRA_INT_STATUS, -1);
			int appearance = intent.getIntExtra(Constants.EXTRA_INT_APPEARANCE, 0);
			boolean inverse = intent.getBooleanExtra(Constants.EXTRA_BOOL_INVERSE_COLOR, false);
			sendNotification(context, status, appearance, inverse);
			
		} else if (Constants.ACTION_START_QS.equals(action)) {
			
			new Handler().post(new Runnable() {
				public void run() {
	               Intent intent = new Intent(context, ShowSettingsActivity.class);
	               intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	               context.startActivity(intent); 					
				}
			});
		} else if(ACTION_ROTATE.equals(action)) {
			new Handler().post(new Runnable() {
				public void run() {
				   int value = Settings.System.getInt(context.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0);
				   //Auto Rotation off
				   if(value == 1) {
					   Settings.System.putInt(context.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0);	
					   mNotification.contentView.setImageViewResource(R.id.btn_rotate, R.drawable.auto_rotate_off);
					   Toast.makeText(context, "Auto Rotation OFF", Toast.LENGTH_SHORT).show();
				   }
				   //Auto Rotation on
				   else {
					   Settings.System.putInt(context.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 1);
					   mNotification.contentView.setImageViewResource(R.id.btn_rotate, R.drawable.auto_rotate_on);
					   Toast.makeText(context, "Auto Rotation ON", Toast.LENGTH_SHORT).show();
				   }
				}
			});
		} else if(ACTION_AIRPLANE.equals(action)) {
			new Handler().post(new Runnable() {
				public void run() {
				   int value = Settings.System.getInt(context.getContentResolver(), Settings.System.AIRPLANE_MODE_ON, 0);
				   //Air plane mode off
				   if(value == 1) {
					   Settings.System.putInt(context.getContentResolver(), Settings.System.AIRPLANE_MODE_ON, 0);	
//					   mNotification.contentView.setImageViewResource(R.id.btn_rotate, R.drawable.airplane_off);
					   Toast.makeText(context, "Air plane mode OFF", Toast.LENGTH_SHORT).show();
				   }
				   //Air plane mode on
				   else {
					   Settings.System.putInt(context.getContentResolver(), Settings.System.AIRPLANE_MODE_ON, 1);
//					   mNotification.contentView.setImageViewResource(R.id.btn_rotate, R.drawable.airplane_on);
					   Toast.makeText(context, "Air plane mode ON", Toast.LENGTH_SHORT).show();
				   }
				}
			});
		} else if(ACTION_BRIGHTNESS.equals(action)) {
			new Handler().post(new Runnable() {
				public void run() {
				   int value = Settings.System.getInt(context.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 0);
				   
				   //Si max alors passe a min
				   if(value == MAXIMUM_BACKLIGHT) {
					   value = MINIMUM_BACKLIGHT;
				   }
				   //Sinon augmente jusqu a max
				   else {
					   value = value + RANGE_BACKLIGHT;
					   
					   if(value > MAXIMUM_BACKLIGHT) {
						   value = MAXIMUM_BACKLIGHT;
					   }					   
				   }
				   
				   Settings.System.putInt(context.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, value);
				   Toast.makeText(context, "Set brightness to "+value, Toast.LENGTH_SHORT).show();
				}
			});
		} else if(ACTION_SILENT.equals(action)) {
			new Handler().post(new Runnable() {
				public void run() {
					
					if (audioManager == null) {
						audioManager = (AudioManager) context.getSystemService(Activity.AUDIO_SERVICE);
					}
					
					if (audioManager.getRingerMode() == AudioManager.RINGER_MODE_SILENT) {
					    audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
					    Toast.makeText(context, "Set ringermode to normal", Toast.LENGTH_SHORT).show();
					} 
					else if (audioManager.getRingerMode() != AudioManager.RINGER_MODE_SILENT) {
						audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
						Toast.makeText(context, "Set ringermode to silent", Toast.LENGTH_SHORT).show();
					}
					
				}
			});
		} else if(ACTION_MEDIAVOLUME.equals(action)) {
			new Handler().post(new Runnable() {
				public void run() {
					
				   if (audioManager == null) {
					  audioManager = (AudioManager) context.getSystemService(Activity.AUDIO_SERVICE);
				   }
					
				   int value = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
				   int maxValue = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
					
				   //Si max alors passe a min
				   if(value == maxValue) {
					   value = 0;
				   }
				   //Sinon max
				   else {
					   value = maxValue;
				   }
				   
				   audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0);
				   Toast.makeText(context, "Set audio volume to "+value, Toast.LENGTH_SHORT).show();
				}
			});
		} else if(ACTION_DATA1.equals(action)) {
			new Handler().post(new Runnable() {
				public void run() {
					
					final ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
					
					final NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
					
					//attempt to connect to network
					if(networkInfo != null) {
						if(networkInfo.getState() != NetworkInfo.State.CONNECTED) {
							setMobileDataEnabled(connectivityManager, true, context);
							Toast.makeText(context, "Enable mobile data", Toast.LENGTH_SHORT).show();
						}
						else {
							setMobileDataEnabled(connectivityManager, false, context);							
							Toast.makeText(context, "Disable mobile data", Toast.LENGTH_SHORT).show();
						}
					}
				}
			});
		} else if(ACTION_DATA2.equals(action)) {
			new Handler().post(new Runnable() {
				public void run() {
//					Intent intent = new Intent(Intent.ACTION_VIEW); 
//					intent.setClassName("com.android.phone", "com.android.phone.Settings");
//					context.startActivity(intent);
					
					//ou ...
			        Intent intent = new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS);
			        context.startActivity(intent);					
				}
			});
		}	
	}
	
	private synchronized void sendNotification(Context context, int status, int appearance, boolean inverse) {
		
		Notification notification = mNotification;
		if (notification == null) {
			
			// create and cache notification
			notification = new Notification();
			notification.flags |= Notification.FLAG_ONGOING_EVENT;
			notification.flags |= Notification.FLAG_NO_CLEAR;
			RemoteViews view = notification.contentView = new RemoteViews(context.getPackageName(), R.layout.status_bar_event);

			// update view color
//			view.setImageViewResource(R.id.image1, inverse ? R.drawable.ic_logo_white : R.drawable.ic_logo_black);
//			int color = inverse ? Color.WHITE : Color.BLACK;
//			view.setTextColor(R.id.text1, color);
//			view.setTextColor(R.id.text2, color);
			
	    	Intent rotateIntent = new Intent(ACTION_ROTATE, null);
	    	PendingIntent rotatePendingIntent = PendingIntent.getBroadcast(context, 0, rotateIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	    	view.setOnClickPendingIntent(R.id.btn_rotate, rotatePendingIntent);

	    	Intent airPlaneIntent = new Intent(ACTION_AIRPLANE, null);
	    	PendingIntent airPlanePendingIntent = PendingIntent.getBroadcast(context, 1, airPlaneIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	    	view.setOnClickPendingIntent(R.id.btn_airplane, airPlanePendingIntent);

	    	Intent brightnessIntent = new Intent(ACTION_BRIGHTNESS, null);
	    	PendingIntent brightnessPendingIntent = PendingIntent.getBroadcast(context, 2, brightnessIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	    	view.setOnClickPendingIntent(R.id.btn_brightness, brightnessPendingIntent);

	    	Intent silentIntent = new Intent(ACTION_SILENT, null);
	    	PendingIntent silentPendingIntent = PendingIntent.getBroadcast(context, 3, silentIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	    	view.setOnClickPendingIntent(R.id.btn_silent, silentPendingIntent);
	    	
	    	Intent mediaVolumeIntent = new Intent(ACTION_MEDIAVOLUME, null);
	    	PendingIntent mediaVolumePendingIntent = PendingIntent.getBroadcast(context, 4, mediaVolumeIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	    	view.setOnClickPendingIntent(R.id.btn_mediavolume, mediaVolumePendingIntent);

	    	Intent data1Intent = new Intent(ACTION_DATA1, null);
	    	PendingIntent data1PendingIntent = PendingIntent.getBroadcast(context, 5, data1Intent, PendingIntent.FLAG_UPDATE_CURRENT);
	    	view.setOnClickPendingIntent(R.id.btn_data1, data1PendingIntent);

	    	Intent data2Intent = new Intent(ACTION_DATA2, null);
	    	PendingIntent data2PendingIntent = PendingIntent.getBroadcast(context, 6, data2Intent, PendingIntent.FLAG_UPDATE_CURRENT);
	    	view.setOnClickPendingIntent(R.id.btn_data2, data2PendingIntent);
	    	
	    	mNotification = notification;
		}
		
        //Intent intent = appearance == 0 ? new Intent("com.bwx.bequick.SHOW_FULLSCREEN") : new Intent("com.bwx.bequick.SHOW_DIALOG");

		// create intent depending on the appearance
		Intent intent = new Intent();
        String className = appearance == 0 ? "com.bwx.bequick.MainSettingsActivity" : "com.bwx.bequick.DialogSettingsActivity";
        intent.setClassName("com.bwx.bequick", className);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		notification.contentIntent = PendingIntent.getActivity(context, 0, intent, 0);
		
		NotificationManager mgr = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		if (status == Constants.STATUS_NO_INTEGRATION) {
			
			mgr.cancel(SHORTCUT_NOTIFICATION);
		} else {
			
			boolean sdk9OrLater = Constants.SDK_VERSION >= 9 /*2.3*/;
			
			boolean visible = status != Constants.STATUS_NO_ICON;
			notification.icon = visible 
				? (status == Constants.STATUS_BLACK_ICON ? R.drawable.ic_logo_black : R.drawable.ic_logo_white) 
				: sdk9OrLater ? R.drawable.ic_placeholder : -1;
				
			long hiddenTime = sdk9OrLater ? -Long.MAX_VALUE : Long.MAX_VALUE;
			notification.when = visible ? System.currentTimeMillis() : hiddenTime; // align left (0) / right (max) in status bar
			mgr.notify(SHORTCUT_NOTIFICATION, notification);
		}
	}
	private void setMobileDataEnabled(final ConnectivityManager conman, boolean enabled, Context context) {
		try {
		    final Class conmanClass = Class.forName(conman.getClass().getName());
		    final Field iConnectivityManagerField = conmanClass.getDeclaredField("mService");
		    iConnectivityManagerField.setAccessible(true);
		    final Object iConnectivityManager = iConnectivityManagerField.get(conman);
		    final Class iConnectivityManagerClass = Class.forName(iConnectivityManager.getClass().getName());
		    final Method setMobileDataEnabledMethod = iConnectivityManagerClass.getDeclaredMethod("setMobileDataEnabled", Boolean.TYPE);
		    setMobileDataEnabledMethod.setAccessible(true);
		    setMobileDataEnabledMethod.invoke(iConnectivityManager, enabled);
		} catch (Throwable e) {
			Toast.makeText(context, "Unable to set mobile data to "+e.getMessage(), Toast.LENGTH_SHORT).show();			
		}

	}		
	
}
