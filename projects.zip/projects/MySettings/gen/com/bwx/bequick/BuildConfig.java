/** Automatically generated file. DO NOT MODIFY */
package com.bwx.bequick;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}