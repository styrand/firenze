/** Automatically generated file. DO NOT MODIFY */
package bander.notepad;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}