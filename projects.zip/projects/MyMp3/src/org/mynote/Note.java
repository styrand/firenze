package org.mynote;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Note implements Serializable {
	private long id;
	
	private String content;

	private long date;
	
	public Note() {
	}
	public Note(long id, String content, long date) {
		this.id = id;
		this.content = content;
		this.date = date;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public long getDate() {
		return date;
	}

	public void setDate(long date) {
		this.date = date;
	}
	public String fmtTitle() {
		if(content != null) {
			int io = content.indexOf("\n"); 
			if(io != -1) {
				return content.substring(0, io);
			}
			if(content.length() < 15) {
				return content;
			}
			else {
				return content.substring(0, 10) + " ...";
			}
		}
		return null;
	}
	public String fmtDetail() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE);
		Date dd = new Date(date);		
		return sdf.format(dd);
	}

	
}
