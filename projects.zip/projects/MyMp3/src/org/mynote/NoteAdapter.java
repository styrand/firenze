package org.mynote;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class NoteAdapter extends BaseAdapter {
	private ArrayList<Note> noteList;
	private LayoutInflater noteInf;

//	public NoteAdapter(Context c, ArrayList<Note> noteList){
//		this.noteList = noteList;
//		noteInf = LayoutInflater.from(c);
//	}
	public NoteAdapter(Context c){
		noteInf = LayoutInflater.from(c);
	}
	
	@Override
	public int getCount() {
		return noteList.size();
	}

	@Override
	public Object getItem(int arg0) {
		return null;
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
	  //map to song layout
	  LinearLayout noteLayout = (LinearLayout)noteInf.inflate(R.layout.note, parent, false);
	  
	  if(noteList != null && position < noteList.size()) {
		  final Note note = noteList.get(position);	  
		  
		  final TextView titleView = (TextView)noteLayout.findViewById(R.id.noteTitle);
		  final TextView detailView = (TextView)noteLayout.findViewById(R.id.noteDetail);
		  
		  if(position == 0) {
			  titleView.setText(note.getContent());
			  titleView.setTypeface(Typeface.DEFAULT);
			  titleView.setSingleLine(false);
		  }
		  else {
			  titleView.setSingleLine(true);
			  titleView.setText(note.fmtTitle());
			  titleView.setTypeface(Typeface.DEFAULT_BOLD);
			  
			  detailView.setText(note.fmtDetail());
			  detailView.setTypeface(Typeface.DEFAULT);			  			  
		  }
		  
		  
		  //set position as tag
		  noteLayout.setTag(position);		  
	  }
	  
	  return noteLayout;
	}
	public ArrayList<Note> getNoteList() {
		return noteList;
	}
	public void setNoteList(ArrayList<Note> noteList) {
		this.noteList = noteList;
	}


}
