package org.mynote;


import java.util.ArrayList;

import android.app.Activity;
import android.app.ListActivity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.widget.AdapterView;
import android.widget.ListView;

public final class MyNote extends ListActivity { 
	protected static final int MENU_EDIT = 1;

	protected static final int MENU_CLOSE = 2;

	private static final int ADD_NOTE = 1;

	private static final int EDIT_NOTE = 2;
	
	private ArrayList<Note> noteList;
	
	private NoteAdapter noteAdapter;
	
	private MyNoteDb db;
	
//	private Cursor cursor;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	try {
            super.onCreate(savedInstanceState);

            setContentView(R.layout.main);
            
    		// initialization of database helper
        	db = new MyNoteDb(getApplicationContext());
        	
            noteAdapter = new NoteAdapter(this);
            setListAdapter(noteAdapter);
                        
            updateData();

//            getListView().setOnCreateContextMenuListener(new OnCreateContextMenuListener() {
//    			public void onCreateContextMenu(ContextMenu menu, View view, ContextMenuInfo menuInfo) {
//    				menu.add(0, MENU_EDIT, Menu.NONE, "Edit");
//    				menu.add(0, MENU_CLOSE, Menu.NONE, "Close");
//    			}
//            });
//            
		} catch (Throwable e) {
			Utils.showDialog(this, e);
		}
    }
    public void updateData() {
    	noteList = new ArrayList<Note>();
    	
		// getting readable database
		SQLiteDatabase sqliteDb = db.getReadableDatabase();
		// getting notes from db
		// see dbhelper for more details
		Cursor cursor = db.getNotes(sqliteDb);
		
//		startManagingCursor(cursor);

		db.close();		
    	
    	if(cursor!=null && cursor.moveToFirst()) {
    		  //get columns
    		  int idColumn = cursor.getColumnIndex(MyNoteDb.KEY_ID);
    		  int contentColumn = cursor.getColumnIndex(MyNoteDb.KEY_CONTENT);
    		  int dateColumn = cursor.getColumnIndex(MyNoteDb.KEY_DATE);
    		  
    		  //add songs to list
    		  do {
    		    long id = cursor.getLong(idColumn);
    			String content = cursor.getString(contentColumn);
    			long date = cursor.getLong(dateColumn);
            		
    		    noteList.add(new Note(id, content, date));
    		  }
    		  while (cursor.moveToNext());
   		}
    	
    	noteAdapter.setNoteList(noteList);
    	
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
            	noteAdapter.notifyDataSetChanged();    	
            }
        });    	
    	
   	}
    private int findNoteIndexById(long id) {
    	for(int i=0;i<noteList.size();i++) {
    		Note e = noteList.get(i);
    		if(e.getId() == id) {
    			return i;
    		}
    	}
    	return -1;
    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {		
		    case R.id.actionAdd: 
			    Intent intentAdd = new Intent(this, NoteActivity.class);
			    intentAdd.putExtra("noteList", noteList);
			    startActivityForResult(intentAdd, ADD_NOTE);			    	
			    break;
			case R.id.actionEnd: 
			case MENU_CLOSE: 
		    	System.exit(0);
				break;
			case MENU_EDIT:
				long id = ((AdapterView.AdapterContextMenuInfo) item.getMenuInfo()).id;				
			    int index = findNoteIndexById(id);
			    if(index != -1) {
				    Intent intent = new Intent(this, NoteActivity.class);
				    Note note = noteList.get(index);
				    intent.putExtra("index", index);
				    intent.putExtra("note", note);
				    intent.putExtra("noteList", noteList);
				    startActivityForResult(intent, EDIT_NOTE);			    	
			    }
				break;
		}
		return true;
	}
   @Override
   protected void onDestroy() {
      super.onDestroy();
   }
   @Override
   protected void onListItemClick(ListView listView, View view, int position, long id) {
      Intent intent = new Intent(this, NoteActivity.class);
      int index = Integer.parseInt(view.getTag().toString());
      Note note = noteList.get(index);
      intent.putExtra("index", index);
      intent.putExtra("note", note);
      intent.putExtra("noteList", noteList);
      startActivity(intent);
   }
	@Override
	protected void onResume() {
		super.onResume();
//		updateData();
	}   
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
	    // Check which request we're responding to
	    if (requestCode == ADD_NOTE) {
	        // Make sure the request was successful
	        if (resultCode == Activity.RESULT_OK) {
	        	updateData();
	        }
	    }
	    else if (requestCode == EDIT_NOTE) {
	        // Make sure the request was successful
	        if (resultCode == Activity.RESULT_OK) {
	        	updateData();
	        }
	    }
	}	
}
