package org.mynote;

import java.util.Date;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyNoteDb extends SQLiteOpenHelper {
	private Context ctx;
	
	//version of database
	private static final int version = 1;
	
	//database name
	private static final String DB_NAME = "notes";
	
	//name of table
	private static final String TABLE_NAME = "notes";
	
	//column names
	public static final String KEY_ID = "id";
	public static final String KEY_CONTENT = "content";
	public static final String KEY_DATE = "date";
	//sql query to creating table in database
	private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (id INTEGER PRIMARY KEY AUTOINCREMENT, "+KEY_CONTENT+" TEXT NOT NULL, "+KEY_DATE+" DATETIME);";

	public MyNoteDb(Context context) {
		super(context, DB_NAME, null, version);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(CREATE_TABLE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		db.execSQL("DROP TABLE IF EXIST " + TABLE_NAME);
		onCreate(db);	
	}
	
	//function for adding the note to database
	public Note addNote(String content) {
		SQLiteDatabase db = this.getWritableDatabase();
		
		//creating the contentValues object
		//read more here -> http://developer.android.com/reference/android/content/ContentValues.html
		ContentValues cv = new ContentValues();
		cv.put(KEY_CONTENT, content);
		cv.put(KEY_DATE, new Date().getTime());
		
		//inserting the note to database
		long id = db.insert(TABLE_NAME, null, cv);
		Note note = null;
		if(id != -1) {
			Cursor cursor = getNote(db, id);
  		  //get columns
  		  int idColumn = cursor.getColumnIndex(MyNoteDb.KEY_ID);
  		  int contentColumn = cursor.getColumnIndex(MyNoteDb.KEY_CONTENT);
  		  int dateColumn = cursor.getColumnIndex(MyNoteDb.KEY_DATE);
  		  
  		    long id2 = cursor.getLong(idColumn);
  			String content2 = cursor.getString(contentColumn);
  			long date = cursor.getLong(dateColumn);
          		
  		    note = new Note(id2, content2, date);
		}
		
		//closing the database connection
		db.close();
		
		//see that all database connection stuff is inside this method
		//so we don't need to open and close db connection outside this class
		return note;
	}
	//getting all notes
	public Cursor getNotes(SQLiteDatabase db) {
		//db.query is like normal sql query
		//cursor contains all notes 
		Cursor c = db.query(TABLE_NAME, new String[] {KEY_ID, KEY_CONTENT, KEY_DATE}, null, null, null, null, "date DESC");
		//moving to the first note
		c.moveToFirst();
		//and returning Cursor object
		return c;
	}
	private Cursor getNote(SQLiteDatabase db, long id) {		
		Cursor c = db.query(TABLE_NAME, new String[] {KEY_ID, KEY_CONTENT, KEY_DATE}, KEY_ID + " = ?", new String[] { String.valueOf(id) }, null, null, null);
		c.moveToFirst();
		return c;
	}
	
	public void deleteNote(long id) {
		SQLiteDatabase db = getWritableDatabase();
		db.delete(TABLE_NAME, KEY_ID + " = ?", new String[] { String.valueOf(id) });
		db.close();
	}
	
	public void updateNote(long id, String content) {
		SQLiteDatabase db = this.getWritableDatabase();
		
		ContentValues cv = new ContentValues();
		cv.put(KEY_ID, id);
		cv.put(KEY_CONTENT, content);
		cv.put(KEY_DATE, new Date().getTime());
		
		db.update(TABLE_NAME, cv, KEY_ID + " = ?", new String[] { String.valueOf(id) });
		
		db.close();
		
		
	}
	

}
