package org.mynote;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

public class NoteActivity extends Activity {
    private Note note;
//    private int index;
//    private ArrayList<Note> noteList;
//	private NotificationManager notificationManager;
	
//	private MyNoteDb db;
	
	private EditText noteContent; 
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	try {
            super.onCreate(savedInstanceState);

//        	if (notificationManager == null) {
//            	notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//            }
            
            setContentView(R.layout.note_activity);
            
            noteContent = (EditText) findViewById(R.id.noteContent);
            
//            noteList = (ArrayList<Note>)getIntent().getSerializableExtra("noteList");
            note = (Note)getIntent().getSerializableExtra("note");
                        
            //update mode
            if(note != null) {
                
//                index = getIntent().getIntExtra("index", 0);            	
                noteContent.setText(note.getContent());
                
    	        //display notification
//    	        createNotification(note.fmtTitle(), "Editing");
    	    }
            //create mode do nothing here

            
		} catch (Throwable e) {
			Utils.showDialog(this, e);
		}
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.note_activity, menu);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {		
			case R.id.actionEnd: 
				Intent returnIntentE =  getIntent(); // new Intent();
				setResult(Activity.RESULT_CANCELED, returnIntentE);
				finish();
			break;
			case R.id.actionSave:
				if(noteContent.getText() != null) {
					String content = noteContent.getText().toString();		
					if(content != null && content.length() > 5) {
						// initialization of database helper
				    	MyNoteDb db = new MyNoteDb(getApplicationContext());
				    	
						//Create mode
						if(note == null) {
					    	note = db.addNote(content);
						}
						//Update mode
						else {
							db.updateNote(note.getId(), content);
						}
						
						db.close();
					}
				}
				Intent returnIntent = getIntent(); // new Intent();
				setResult(Activity.RESULT_OK, returnIntent);
				finish();
			break;
			case R.id.actionDelete:
				if(note != null) {
					// initialization of database helper
			    	MyNoteDb db = new MyNoteDb(getApplicationContext());
			    	db.deleteNote(note.getId());
					db.close();
				}
				Intent returnIntentD =  getIntent(); // new Intent();
				setResult(Activity.RESULT_OK, returnIntentD);
				finish();
			break;
		}
		return true;
	}
//	protected void createNotification(String title, String text) {
//		Notification notification = new Notification(R.drawable.icon, text, System.currentTimeMillis());
//		Intent notificationIntent = new Intent(this, NoteActivity.class);
//		PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
//		notification.setLatestEventInfo(this, title, text, contentIntent);
//		notificationManager.notify(0, notification);
//	}
	
	
    
}
