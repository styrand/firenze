package org.mynote;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class Utils {
  public static void showDialog(Context context, Throwable e) {
	    final AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setIcon(android.R.drawable.ic_dialog_info);		
		builder.setTitle("Exception thrown");
		builder.setMessage(e.getClass().getName()+" : "+e.getMessage());
		
	    builder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) { 
	        	dialog.cancel();
	        }
	     });
	    builder.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) { 
	        	dialog.cancel();
	        }
	     });
	     builder.show();		  
  }
}
