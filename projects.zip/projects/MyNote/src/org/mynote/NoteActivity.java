package org.mynote;

import java.util.Date;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

public class NoteActivity extends Activity {
//	private NotificationManager notificationManager;
	
	private Long id;
	
	private EditText noteContent; 
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	try {
    		super.onCreate(savedInstanceState);

            setContentView(R.layout.note_activity);
    		setResult(RESULT_CANCELED);
    		
    		Intent intent = getIntent();
    		

            noteContent = (EditText) findViewById(R.id.noteContent);
            
    		if (intent.getAction().equals(Intent.ACTION_INSERT)) {
    		}
    		else if (intent.getAction().equals(Intent.ACTION_EDIT)) {
				Cursor cursor = getContentResolver().query(intent.getData(), NoteContentProvider.PROJECTION, null, null, null);
				
				if (cursor.moveToNext()) {
					id = cursor.getLong(0);
					noteContent.setText(cursor.getString(1));
				} 
				else {
					finish();
				}
				cursor.close();
    		}
            
            
		} catch (Throwable e) {
			Utils.showDialog(this, e);
		}
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.note_activity, menu);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
	Utils.showDialog(this, "onMenuItemSelected "+item.getItemId()+" "+noteContent.getText().toString());
	
		switch (item.getItemId()) {		
			case R.id.actionEnd: 
		    	finish();
			break;
			case R.id.actionSave:
				Utils.showDialog(this, "actionSave 1");
				if(noteContent.getText() != null) {
					String content = noteContent.getText().toString();		
					Utils.showDialog(this, "actionSave 2");
					if(content != null && content.length() > 5) {
						Utils.showDialog(this, "actionSave 3");
						ContentValues values = new ContentValues();
						values.put(NoteContentProvider.KEY_CONTENT, content);
						values.put(NoteContentProvider.KEY_DATE, new Date().getTime());
						
						//Create mode
						if(id == null) {
							Utils.showDialog(this, "actionSave 4");
							getContentResolver().insert(NoteContentProvider.NOTES_URI, values);
							Utils.showDialog(this, "actionSave 5");
							setResult(RESULT_OK);
							Utils.showDialog(this, "actionSave 6");
						}
						//Update mode
						else {
							Utils.showDialog(this, "actionSave 7");
							getContentResolver().update(getIntent().getData(), values, null, null);							
							Utils.showDialog(this, "actionSave 8");
							setResult(RESULT_OK);
							Utils.showDialog(this, "actionSave 9");
						}
						
					}
				}
				finish();
				Utils.showDialog(this, "actionSave 10");
				//Intent intent1 = new Intent(this, MyNote.class);
				//startActivity(intent1);			    									
			break;
			case R.id.actionDelete:
				if(id != null) {
					getContentResolver().delete(getIntent().getData(), null, null);
					setResult(RESULT_OK);
				}
				finish();
				//Intent intent2 = new Intent(this, MyNote.class);
				//startActivity(intent2);			    					
			break;
		}
		
		//finish();
		return true;
	}
//	protected void createNotification(String title, String text) {
//		Notification notification = new Notification(R.drawable.icon, text, System.currentTimeMillis());
//		Intent notificationIntent = new Intent(this, NoteActivity.class);
//		PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
//		notification.setLatestEventInfo(this, title, text, contentIntent);
//		notificationManager.notify(0, notification);
//	}
	
	
    
}
