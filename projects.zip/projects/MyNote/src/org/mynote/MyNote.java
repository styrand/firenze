package org.mynote;


import android.app.ListActivity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.widget.AdapterView;
import android.widget.ListView;

public final class MyNote extends ListActivity { 
	protected static final int MENU_EDIT = 1;

	protected static final int MENU_CLOSE = 2;
	
	private NoteAdapter noteAdapter;
	
	// package scope
	static NotificationManager notificationManager;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	try {
            super.onCreate(savedInstanceState);

        	if (notificationManager == null) {
            	notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            }
            
//            setContentView(R.layout.main);
//
//            noteList = new ArrayList<Note>();
//            
//            getNoteList();
//            
            noteAdapter = new NoteAdapter(this);
            setListAdapter(noteAdapter);
            
            getListView().setOnCreateContextMenuListener(new OnCreateContextMenuListener() {
    			public void onCreateContextMenu(ContextMenu menu, View view, ContextMenuInfo menuInfo) {
    				menu.add(0, MENU_EDIT, Menu.NONE, "Edit");
    				menu.add(0, MENU_CLOSE, Menu.NONE, "Close");
    			}
            });
		} catch (Throwable e) {
			Utils.showDialog(this, e);
		}
    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {		
		    case R.id.actionAdd: 
		    	Intent intentA = new Intent(Intent.ACTION_INSERT); 
		    	intentA.setData(NoteContentProvider.NOTES_URI);
				startActivity(intentA);
			    break;
			case R.id.actionEnd: 
			case MENU_CLOSE: 
		    	System.exit(0);
				break;
			case MENU_EDIT:
				long id = ((AdapterView.AdapterContextMenuInfo) item.getMenuInfo()).id;
		    	Intent intentE = new Intent(Intent.ACTION_EDIT); 
		    	intentE.setData(NoteContentProvider.noteUri(id));
				startActivity(intentE);
				break;
		}
		return true;
	}
   @Override
   protected void onDestroy() {
      super.onDestroy();
   }
   @Override
   protected void onListItemClick(ListView listView, View view, int position, long id) {
    	Intent intentE = new Intent(Intent.ACTION_EDIT); 
    	intentE.setData(NoteContentProvider.noteUri(id));
		startActivity(intentE);
   }
	@Override
	protected void onResume() {
		super.onResume();
		if (MyNote.notificationManager != null) {
			notificationManager.cancel(0);
		}
	}   
	
}
