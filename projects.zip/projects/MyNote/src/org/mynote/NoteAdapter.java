package org.mynote;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Handler;
import android.view.View;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;


public class NoteAdapter extends ResourceCursorAdapter {

	private int idColumn;
	private int contentColumn;
	private int dateColumn;
	
	private Handler handler;
	private SimpleTask updateTask;
	
	
	public NoteAdapter(Activity activity) {
		super(activity, R.layout.note, activity.managedQuery(NoteContentProvider.NOTES_URI, null, null, null, "date desc"));		
		//get columns
		idColumn = getCursor().getColumnIndex(NoteContentProvider.KEY_ID);
		contentColumn = getCursor().getColumnIndex(NoteContentProvider.KEY_CONTENT);
		dateColumn = getCursor().getColumnIndex(NoteContentProvider.KEY_DATE);
		
		handler = new Handler();
		updateTask = new SimpleTask() {
			@Override
			public void runControlled() {
				NoteAdapter.super.onContentChanged();
				cancel(); // cancel the task such that it does not run more than once without explicit intention
			}
			
			@Override
			public void postRun() {
				if (getPostCount() > 1) { // enforce second run even if task is canceled
					handler.postDelayed(updateTask, 1500);
				}
			}
		};
		
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
		  //get title and artist views
		  TextView titleView = (TextView)view.findViewById(R.id.noteTitle);
		  TextView detailView = (TextView)view.findViewById(R.id.noteDetail);
		  
		  final long id = cursor.getLong(idColumn);
		  final String content = cursor.getString(contentColumn);
		  final long timestamp = cursor.getLong(dateColumn);
		  
		  titleView.setText(fmtTitle(content));
		  titleView.setTypeface(Typeface.DEFAULT_BOLD);
		  
		  detailView.setText(fmtDetail(timestamp));
		  detailView.setTypeface(Typeface.DEFAULT);		  
		
	}
	
	@Override
	protected synchronized void onContentChanged() {
		/*
		 * we delay the second(!) content change by 1.5 second such that it gets called at most once per 1.5 seconds 
		 * to take stress away from the UI and avoid not needed updates
		 */
		if (!updateTask.isPosted()) {
			super.onContentChanged();
			updateTask.post(2); // we post 2 tasks
			handler.postDelayed(updateTask, 1500); // waits one second until the task gets unposted
			updateTask.cancel(); // put the canceled task in the queue to enable it again optionally
		} else {
			if (updateTask.getPostCount() < 2) {
				updateTask.post(); // enables the task and adds a new one
			} else {
				updateTask.enable();
			}
		}
	}
	
	public String fmtTitle(String content) {
		if(content != null) {
			int io = content.indexOf("\n"); 
			if(io != -1) {
				return content.substring(0, io);
			}
			if(content.length() < 15) {
				return content;
			}
			else {
				return content.substring(0, 10) + " ...";
			}
		}
		return null;
	}
	public String fmtDetail(long time) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE);
		Date dd = new Date(time);		
		return sdf.format(dd);
	}
	
//	private ArrayList<Note> noteList;
//	private LayoutInflater noteInf;
//
//	public NoteAdapter(Context c, ArrayList<Note> noteList){
//		this.noteList = noteList;
//		noteInf = LayoutInflater.from(c);
//	}
//	
//	@Override
//	public int getCount() {
//		return noteList.size();
//	}
//
//	@Override
//	public Object getItem(int arg0) {
//		return null;
//	}
//
//	@Override
//	public long getItemId(int arg0) {
//		return 0;
//	}
//
//	@Override
//	public View getView(int position, View convertView, ViewGroup parent) {
//	  //map to song layout
//	  LinearLayout noteLayout = (LinearLayout)noteInf.inflate(R.layout.note, parent, false);
//	  //get title and artist views
//	  TextView titleView = (TextView)noteLayout.findViewById(R.id.noteTitle);
//	  TextView detailView = (TextView)noteLayout.findViewById(R.id.noteDetail);
//	  //get track using position
//	  Note note = noteList.get(position);
//	  //get title and artist strings
//	  titleView.setText(note.fmtTitle());
//	  titleView.setTypeface(Typeface.DEFAULT_BOLD);
//	  
//	  detailView.setText(note.fmtDetail());
//	  detailView.setTypeface(Typeface.DEFAULT);
//	  
//	  //set position as tag
//	  noteLayout.setTag(position);
//	  return noteLayout;
//	}


}
