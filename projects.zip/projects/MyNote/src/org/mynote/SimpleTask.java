/**
 * Firenze rss
 * 
 * Copyright (c) 2012 Stefan Handschuh
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

package org.mynote;


public abstract class SimpleTask implements Runnable {
	private boolean canceled = false;
	
	private int postCount = 0;
	
	public abstract void runControlled();
	
	public void cancel() {
		canceled = true;
	}
	
	public boolean isCanceled() {
		return canceled;
	}
	
	public void post() {
		post(1);
	}
	
	public synchronized void post(int count) {
		postCount += count;
		canceled = false;
	}
	
	public boolean isPosted() {
		return postCount > 0;
	}
	
	public int getPostCount() {
		return postCount;
	}

	public final synchronized void run() {
		if (!canceled) {
			runControlled();
		}
		postRun();
		postCount--;
	}
	
	/**
	 * Override to use
	 */
	public void postRun() {
		
	}

	public void enable() {
		canceled = false;
	}

}
