package org.mynote;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.Environment;
import java.io.File;

public class NoteContentProvider extends ContentProvider {
	private static final String FOLDER = Environment.getExternalStorageDirectory()+"/mynote/";
	
	public static final String AUTHORITY = "org.mynote.Note";
	
	private static UriMatcher URI_MATCHER;
	
	private static final int URI_NOTES = 1;

	private static final int URI_NOTE = 2;
	
	private NoteDb db;
	
	//database name
	private static final String DB_NAME = "notes.db";
	
	//name of table
	private static final String TABLE_NAME = "notes";
	
	//column names
	public static final String KEY_ID = "_id";
	public static final String KEY_CONTENT = "content";
	public static final String KEY_DATE = "date";
	
	public static final String[] PROJECTION = new String[] {KEY_ID, KEY_CONTENT, KEY_DATE};
	
	
	public static final Uri NOTES_URI = Uri.parse("content://org.mynote.Note/notes");
	
	//version of database
	private static final int version = 1;
	
	static {
		URI_MATCHER = new UriMatcher(UriMatcher.NO_MATCH);
		URI_MATCHER.addURI(AUTHORITY, "notes", URI_NOTES);
		URI_MATCHER.addURI(AUTHORITY, "notes/#", URI_NOTE);
	}
	
	@Override
	public boolean onCreate() {
		try {
			File folder = new File(FOLDER);
			
			folder.mkdir(); // maybe we use the boolean return value later
		} catch (Exception e) {
			
		}
	
		db = new NoteDb(getContext(), DB_NAME, version);
		return true;
	}
	public static Uri noteUri(long id) {
		return Uri.parse("content://org.mynote.Note/notes/"+id);		
	}
	
	private static class NoteDb extends SQLiteOpenHelper {
		//sql query to creating table in database
		private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "+KEY_CONTENT+" TEXT NOT NULL, "+KEY_DATE+" DATETIME);";
		

		public NoteDb(Context context, String name, int version) {
			super(context, name, null, version);
		}
		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(CREATE_TABLE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			db.execSQL("DROP TABLE IF EXIST " + TABLE_NAME);
			onCreate(db);	
		}
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		int option = URI_MATCHER.match(uri);
		
		String where = null;
		
		SQLiteDatabase database = db.getWritableDatabase();
		
		switch(option) {
			case URI_NOTE : {
				long id = Long.parseLong(uri.getPathSegments().get(1));				
				where = KEY_ID + "=" + id;
				break;
			}
		}
		
		int count = 0; 
		
		if(where != null) {
			database.delete(TABLE_NAME, where, selectionArgs);			
		}
		
		if (count > 0) {
			getContext().getContentResolver().notifyChange(uri, null);
		}
		return count;
	}

	@Override
	public String getType(Uri uri) {
		int option = URI_MATCHER.match(uri);
		
		switch(option) {
			case URI_NOTES : return "vnd.android.cursor.dir/vnd.mynote.note";
			case URI_NOTE : return "vnd.android.cursor.item/vnd.mynote.note";
			default : throw new IllegalArgumentException("Unknown URI: "+uri);
		}
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
		SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
		
		int option = URI_MATCHER.match(uri);
		
//		if ((option == URI_FEED || option == URI_FEEDS) && sortOrder == null) {
//			sortOrder = FeedData.FEED_DEFAULTSORTORDER;
//		}
		
		switch(option) {
			case URI_NOTES : {
				queryBuilder.setTables(TABLE_NAME);
				break;
			}
			case URI_NOTE : {
				queryBuilder.setTables(TABLE_NAME);
				queryBuilder.appendWhere(KEY_ID +  "=" + uri.getPathSegments().get(1));
				break;
			}
		}
		
		SQLiteDatabase database = db.getReadableDatabase();
		
		Cursor cursor = queryBuilder.query(database, projection, selection, selectionArgs, null, null, sortOrder);

		cursor.setNotificationUri(getContext().getContentResolver(), uri);
		return cursor;
	}
	
	@Override
	public Uri insert(Uri uri, ContentValues values) {
		long newId = -1;
		
		int option = URI_MATCHER.match(uri);
		
		SQLiteDatabase database = db.getWritableDatabase();
		
		switch (option) {
			case URI_NOTES : {
				newId = database.insert(TABLE_NAME, null, values);
				break;
			}
			default : throw new IllegalArgumentException("Illegal insert");
		}
		if (newId > -1) {
			getContext().getContentResolver().notifyChange(uri, null);
			return ContentUris.withAppendedId(uri, newId);
		} 
		else {
			throw new SQLException("Could not insert row into "+uri);
		}
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		int option = URI_MATCHER.match(uri);
		
		String where = null;
		
		SQLiteDatabase database = db.getWritableDatabase();
		
		switch(option) {
			case URI_NOTE : {
				long id = Long.parseLong(uri.getPathSegments().get(1));				
				where = KEY_ID + "=" + id;
				break;
			}
		}

		int count = 0;
		if(where != null) {
			count = database.update(TABLE_NAME, values, where, selectionArgs);
			
		}
		if (count > 0) {
			getContext().getContentResolver().notifyChange(uri, null);
		}
		
		return count;
	}
	

}
