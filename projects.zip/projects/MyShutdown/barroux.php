<?php
require_once('simple_html_dom.php');
date_default_timezone_set("Europe/Paris");

$url = 'https://www.radioclassique.fr/radio/emissions/matinale-de-radio-classique/decryptage-de-david-barroux/';
$fmtDate = date("d-m");
$title = "Barroux";


header("Content-type: text/xml; charset=UTF-8");

$questionmark = "?";
echo "<".$questionmark."xml version=\"1.0\" encoding=\"utf-8\"".$questionmark.">
";    
echo "<rss version=\"2.0\"><channel><title>" . $title . "</title><link>" . $url . "</link><description>" . $title . " " . $fmtDate . "</description>
";

$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_HEADER, false);
//curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_REFERER, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
$str = curl_exec($curl);
curl_close($curl);

// Create a DOM object
$html = new simple_html_dom();
// Load HTML from a string
$html->load($str);

// Find all with the titre classes
$elements = $html->find('a[href*="mp3"]');

$already_written = array();

$pubTime = time();

foreach($elements as $element)   {
    
    $u = $element->href; 
    $url_article = trim($u);
    
    $label = getShortUrl($u);
          
    echo "<item><title>" . $label . "</title><link>" . $url_article . "</link>" ;
    echo "<enclosure url=\"" . $url_article . "\" type=\"audio/mpeg\" />" ;            
    echo "<guid>" . $url_article . "</guid><pubDate>" . date('D, d M Y H:i:s O', $pubTime) . "</pubDate></item>
";
    
}   

$html->clear(); 
unset($html);

echo "</channel></rss>
";

function getShortUrl($s) {
  $tmpLab = substr($s,strrpos($s, '/')+1) ;
  $tmpLab = substr($tmpLab,0, strrpos($tmpLab, '-')) ;
  return $tmpLab;
}
function contains($s, $finds) {
  foreach($finds as $finds_elt) {
    if(strstr($s, $finds_elt)) {
      return true;
    }
  }
  return false;
}

?>
