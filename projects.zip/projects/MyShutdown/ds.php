<?php

$fullPath = $_POST["u"];

$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_HEADER, false);
//curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_URL, $fullPath);
curl_setopt($curl, CURLOPT_REFERER, $fullPath);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
$str = curl_exec($curl);
curl_close($curl);


    //$fsize = filesize($fullPath);
    $path_parts = pathinfo($fullPath);
    $ext = strtolower($path_parts["extension"]);
    switch ($ext) {
        case "pdf":
        header("Content-type: application/pdf"); // add here more headers for diff. extensions
        header("Content-Disposition: attachment; filename=\"".$path_parts["basename"]."\""); // use 'attachment' to force a download
        break;
//        case "zip":
//        header("Content-type: application/zip"); // add here more headers for diff. extensions
//        header("Content-Disposition: attachment; filename=\"".$path_parts["basename"]."\""); // use 'attachment' to force a download
//        break;
        default;
        header("Content-type: application/octet-stream");
        header("Content-Disposition: filename=\"".$path_parts["basename"]."\"");
    }
    //header("Content-length: $fsize");
    header("Cache-control: private"); //use this to open files directly
 //   while(!feof($fd)) {
 //       $buffer = fread($fd, 2048);
        echo $str;
 //   }
fclose ($fd);
exit;
// example: place this kind of link into the document where the file download is offered:
// <a href="download.php?u=some_file.pdf">Download here</a>
?>
