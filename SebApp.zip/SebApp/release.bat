ant clean release
pause
