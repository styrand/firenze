package fr.styrand.sebapp;

import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
//import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends Activity implements OnClickListener
{
	private LinearLayout root;
	private MyTimer countDownTimer;
	private long msElapsed;
	private boolean timerHasStarted = false;
	private Button recordBtn;
	private TextView tvTime;
	private TextView tvElapsedTime;
	private NotificationManager notificationManager;
	/**
	 * Ms in future : 24 hr 
	 */
	private final long msInFuture = 24 * 3600 * 1000;
	/**
	 * Interval in ms : 1 sec
	 */
	private final long msInterval = 1 * 1000;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.main);
        //Create Timer
        countDownTimer = new MyTimer(msInFuture, msInterval);
        
      //---param for views---
        LinearLayout.LayoutParams containerParams = new LinearLayout.LayoutParams( ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0.0F);
        LinearLayout.LayoutParams widgetParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT, 1.0F);
        
        //Ecran : layout vertical light grey
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.LTGRAY);
        root.setLayoutParams(containerParams);
        
        //Line 1 : layout horizontal grey : time
        LinearLayout l1 = new LinearLayout(this);
        l1.setOrientation(LinearLayout.HORIZONTAL);
        l1.setBackgroundColor(Color.BLACK);
        l1.setLayoutParams(containerParams);
        
        //-- format date
        Date date = Calendar.getInstance().getTime();
        
        //---create a textview---
        tvTime = new TextView(this);
        tvTime.setText(DateFormat.format("HH:mm:ss", date));
        tvTime.setTextSize(48.0F);
        tvTime.setLayoutParams(widgetParams);
 
        l1.addView(tvTime);

        root.addView(l1);

        
        //Line 2 : layout horizontal grey : elapsed time
        LinearLayout l2 = new LinearLayout(this);
        l2.setOrientation(LinearLayout.HORIZONTAL);
        l2.setBackgroundColor(Color.BLUE);
        l2.setLayoutParams(containerParams);
        
        //---create a textview---
        tvElapsedTime = new TextView(this);
        tvElapsedTime.setText("00:00");
        tvElapsedTime.setTextSize(48.0F);
        tvElapsedTime.setLayoutParams(widgetParams);        
 
        l2.addView(tvElapsedTime);
        
        root.addView(l2);
     
        //Line 3 : layout horizontal grey : audio player button
        LinearLayout l3 = new LinearLayout(this);
        l3.setOrientation(LinearLayout.HORIZONTAL);
        l3.setBackgroundColor(Color.RED);
        l3.setLayoutParams(containerParams);
        
        //Ligne 2 : 
        //---create a button rewind---
        Button btnRwd = new Button(this);
        btnRwd.setText("Skip Back");
        btnRwd.setTextSize(24.0F);
        btnRwd.setLayoutParams(widgetParams);
        
        l3.addView(btnRwd);
        
        //---create a button play/pause---
        recordBtn = new Button(this);
        recordBtn.setText("Record");
        recordBtn.setTextSize(24.0F);
        recordBtn.setLayoutParams(widgetParams);
        recordBtn.setOnClickListener(this);
        l3.addView(recordBtn);
         
        //---create a button forward ---
        Button btnFwd = new Button(this);
        btnFwd.setText("Skip Next");
        btnFwd.setTextSize(24.0F);
        btnFwd.setLayoutParams(widgetParams);
        
        l3.addView(btnFwd);
        
        root.addView(l3);

         
//        //---create a layout param for the layout---
//        LinearLayout.LayoutParams layoutParam = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT );
//        this.addContentView(layout, layoutParam);
//        
        setContentView(root);     
        
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	super.onCreateOptionsMenu(menu);
    	createMenu(menu);
    	return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	return createMenuChoice(item);
    }
    private void createMenu(Menu menu) {
    	MenuItem menu1 = menu.add(0, 0, 0, "Item 1");
    {
//    menu1.setIcon(R.drawable.ic_launcher);
    menu1.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
    }
    MenuItem menu2 = menu.add(0, 1, 1, "Orient.");
    {
//    menu2.setIcon(R.drawable.ic_launcher);
    menu2.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
    }
    }
    private boolean createMenuChoice(MenuItem item)
    {
    switch (item.getItemId()) {
    case 0:
    Toast.makeText(this, "You clicked on Item 1",
    Toast.LENGTH_LONG).show();
    return true;
    case 1:
//    Toast.makeText(this, "You clicked on Item 2",
//    Toast.LENGTH_LONG).show();
    	int orientation = getRequestedOrientation();
    	if(orientation == ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT) {
    		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    	}
    	else {
    		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT);
    	}
    
    return true;
    }
    return false;
    }
	@Override
	public void onClick(View view) {
		if (!timerHasStarted) {
			countDownTimer.start();
			timerHasStarted = true;
			recordBtn.setText("Stop");
			setNotification();
		}
		else {
			countDownTimer.cancel();
			timerHasStarted = false;
			recordBtn.setText("Record");
			clearNotification();
		}	
	}
	public class MyTimer extends CountDownTimer {
		public MyTimer(long msInFuture, long msInterval) {
			super(msInFuture, msInterval);
		}
		
		@Override
		public void onFinish() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onTick(long msUntilFinished) {
			msElapsed = msInFuture - msUntilFinished;
			
			long totalSecElapsed = msElapsed / 1000;
			
			long minElapsed = totalSecElapsed / 60;
			long secElapsed = totalSecElapsed % 60;
			
			String s = String.format("%02d:%02d", minElapsed , secElapsed);
			tvElapsedTime.setText(s);
			
	        //-- format date
	        Date date = Calendar.getInstance().getTime();
	        //---create a textview---
	        tvTime.setText(DateFormat.format("HH:mm:ss", date));

		}

	}
    private void setNotification() {
      if (this.notificationManager == null) {
          this.notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
      }
      Notification notification = new Notification(0, "SebApp Running", System.currentTimeMillis());
      Context applicationContext = getApplicationContext();
      Intent notifyIntent = new Intent(this, MainActivity.class);
      String title = "SebApp running";
      String message = "SebApp message";
      PendingIntent wrappedIntent = PendingIntent.getActivity(this, 0, notifyIntent, Intent.FLAG_ACTIVITY_NEW_TASK);
      notification.setLatestEventInfo(applicationContext, title, message, wrappedIntent);
      notification.flags |= Notification.FLAG_AUTO_CANCEL;
      int notificationId = 1;
      this.notificationManager.notify(notificationId, notification);
  }

  private void clearNotification() {
      if (this.notificationManager == null) {
          this.notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
      }
      this.notificationManager.cancelAll();
  }

}
