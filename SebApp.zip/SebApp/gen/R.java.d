C:\temp\SebApp\gen\fr\styrand\sebapp\R.java \
 : C:\temp\SebApp\res\drawable-hdpi\icon.png \
C:\temp\SebApp\res\drawable-hdpi\ic_launcher.png \
C:\temp\SebApp\res\drawable-mdpi\icon.png \
C:\temp\SebApp\res\drawable-mdpi\ic_launcher.png \
C:\temp\SebApp\res\drawable-xhdpi\icon.png \
C:\temp\SebApp\res\drawable-xhdpi\ic_launcher.png \
C:\temp\SebApp\res\drawable-xxhdpi\icon.png \
C:\temp\SebApp\res\drawable-xxhdpi\ic_launcher.png \
C:\temp\SebApp\bin\AndroidManifest.xml \
